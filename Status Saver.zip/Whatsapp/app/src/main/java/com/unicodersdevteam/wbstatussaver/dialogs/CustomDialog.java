package com.unicodersdevteam.wbstatussaver.dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.util.Linkify;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.unicodersdevteam.wbstatussaver.R;



public class CustomDialog {

    private Context context;
    private Dialog dialog;

    public CustomDialog(Context context) {
        this.context = context;
        this.dialog = new Dialog(context);
        this.dialog.setContentView(R.layout.custom_dialog);
        this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }

    public CustomDialog setIcon(int icon) {
        if (icon != 0) {
            ((ImageView) dialog.findViewById(R.id.icon)).setVisibility(View.VISIBLE);
            ((ImageView) dialog.findViewById(R.id.icon)).setImageResource(icon);
        }
        return this;
    }

    public CustomDialog setTitle(String title, boolean isCenterTitle) {
        if (title != null) {
            ((TextView) dialog.findViewById(isCenterTitle ? R.id.center_title : R.id.title)).setVisibility(View.VISIBLE);
            ((TextView) dialog.findViewById(isCenterTitle ? R.id.center_title : R.id.title)).setText(title);
        }
        return this;
    }

    public CustomDialog setMessage(String message) {
        if (message != null) {
            ((TextView) dialog.findViewById(R.id.message)).setVisibility(View.VISIBLE);
            ((TextView) dialog.findViewById(R.id.message)).setText(message);
            Linkify.addLinks(((TextView) dialog.findViewById(R.id.message)), Linkify.WEB_URLS);
            ((TextView) dialog.findViewById(R.id.message)).setLinksClickable(true);
        }
        return this;
    }

    public CustomDialog setView(View view) {
        if (view != null) {
            ((LinearLayout) dialog.findViewById(R.id.custom_view)).setVisibility(View.VISIBLE);
            ((LinearLayout) dialog.findViewById(R.id.custom_view)).addView(view);
        }
        return this;
    }

    public CustomDialog setFullWidth(boolean fullWidth) {
        if (fullWidth) {
            dialog.getWindow().setLayout((int) (dialog.getContext().getResources().getDisplayMetrics().widthPixels * 0.98), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        return this;
    }

    public CustomDialog setCancelable(boolean cancelable) {
        dialog.setCancelable(cancelable);
        return this;
    }

    public CustomDialog setCanceledOnTouchOutside(boolean canceledOnTouchOutside) {
        dialog.setCanceledOnTouchOutside(canceledOnTouchOutside);
        return this;
    }

    public CustomDialog setProgressBar(boolean progressBar) {
        if (progressBar) {
            dialog.findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
        }
        return this;
    }

    public CustomDialog setPositiveButton(String label, OnClickListener onClickListener) {
        if (label != null) {
            dialog.findViewById(R.id.buttonLayout).setVisibility(View.VISIBLE);
            ((TextView) dialog.findViewById(R.id.positiveButton)).setVisibility(View.VISIBLE);
            ((TextView) dialog.findViewById(R.id.positiveButton)).setText(label);
            ((TextView) dialog.findViewById(R.id.positiveButton)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (onClickListener == null) {
                        dismiss();
                    } else {
                        onClickListener.onClick(CustomDialog.this);
                    }
                }
            });
        }
        return this;
    }

    public CustomDialog setNegativeButton(String label, OnClickListener onClickListener) {
        if (label != null) {
            dialog.findViewById(R.id.buttonLayout).setVisibility(View.VISIBLE);
            ((TextView) dialog.findViewById(R.id.negativeButton)).setVisibility(View.VISIBLE);
            ((TextView) dialog.findViewById(R.id.negativeButton)).setText(label);
            ((TextView) dialog.findViewById(R.id.negativeButton)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (onClickListener == null) {
                        dismiss();
                    } else {
                        onClickListener.onClick(CustomDialog.this);
                    }
                }
            });
        }
        return this;
    }

    public CustomDialog show() {
        if (dialog != null) {
            dialog.show();
        }
        return this;
    }

    public CustomDialog dismiss() {
        Activity activity = ((Activity) context);
        if (dialog != null && dialog.isShowing() && activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
            dialog.dismiss();
        }
        return this;
    }

    public interface OnClickListener {
        void onClick(CustomDialog customDialog);
    }
}
