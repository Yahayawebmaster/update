package com.unicodersdevteam.wbstatussaver;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.unicodersdevteam.wbstatussaver.font.FontActivity;
import com.unicodersdevteam.wbstatussaver.fragment.RecentWapp;
import com.unicodersdevteam.wbstatussaver.fragment.RecentWappBus;
import com.unicodersdevteam.wbstatussaver.util.AdController;
import com.unicodersdevteam.wbstatussaver.util.SharedPrefs;
import com.unicodersdevteam.wbstatussaver.util.Utils;
import com.unicodersdevteam.wbstatussaver.dialogs.CustomDialog;
import com.unicodersdevteam.wbstatussaver.warecovermsg.DeletedMsgActivity;
import com.unicodersdevteam.wbstatussaver.waweb.WAWebActivity;
import com.google.android.material.tabs.TabLayout;
import com.ironsource.mediationsdk.IronSource;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //private SlidingRootNav slidingRootNav;
    private DrawerLayout drawerLayout;
    ImageView to_whatsap;

    LinearLayout drw_wapp, drw_wbapp, drw_saved, drw_lang, drw_share, drw_rate, drw_privacy, drw_more, drw_how, drw_web, drw_chat, drw_font, drw_wrecover;
    RelativeLayout nDark;

    ImageView icon_wapp, icon_wbapp, icon_exit, icon_saved, icon_dark, icon_lang, icon_share, icon_rate, icon_privacy, icon_more, icon_how, icon_web, icon_chat, icon_font, icon_wrecover;

    TextView text_wapp, text_wbapp, text_exit, text_saved, text_dark, text_lang, text_share, text_rate, text_privacy, text_more, text_how, text_web, text_chat, text_font, text_wrecover;

    SwitchCompat modeSwitch;

    TabLayout tabLayout;
    ViewPager viewPager;
    String[] tabs;
    Dialog dialog, dialogLang;
    LinearLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Utils.setLanguage(MainActivity.this, SharedPrefs.getLang(MainActivity.this));
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.viewpager);
        setupViewPager(viewPager);

        tabs = new String[2];
        tabs[0] = getResources().getString(R.string.wapp);
        tabs[1] = getResources().getString(R.string.wbapp);
        tabLayout = findViewById(R.id.tablayout);
        tabLayout.setupWithViewPager(viewPager);

        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(getTabViewUn(i));
        }

        setupTabIcons();

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());

                TabLayout.Tab tabs = tabLayout.getTabAt(tab.getPosition());
                tabs.setCustomView(null);
                tabs.setCustomView(getTabView(tab.getPosition()));

//                navigate(null);

                if (tab.getPosition() == 0) {
                    if (isOpedrw_wapp) {
                        isOpedrw_wapp = false;
                        if (!SharedPrefs.getWATree(MainActivity.this).equals("")) {
                            ((RecentWapp) MainActivity.this.getSupportFragmentManager().findFragmentByTag("android:switcher:" + viewPager.getId() + ":" + tab.getPosition())).populateGrid();
                        }
                    }
                }
                if (tab.getPosition() == 1) {
                    if (isOpedrw_wbapp) {
                        isOpedrw_wbapp = false;
                        if (!SharedPrefs.getWBTree(MainActivity.this).equals("")) {
                            ((RecentWappBus) MainActivity.this.getSupportFragmentManager().findFragmentByTag("android:switcher:" + viewPager.getId() + ":" + tab.getPosition())).populateGrid();
                        }
                    }
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                TabLayout.Tab tabs = tabLayout.getTabAt(tab.getPosition());
                tabs.setCustomView(null);
                tabs.setCustomView(getTabViewUn(tab.getPosition()));
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        drawerLayout = findViewById(R.id.drawerLayout);
        NavigationView navigationView = findViewById(R.id.navigationView);

        navigationView.findViewById(R.id.drw_wapp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                drawerLayout.closeDrawers();
                viewPager.setCurrentItem(0);
                setUnpress();
                setPress(icon_wapp, text_wapp, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_wbapp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                drawerLayout.closeDrawers();
                viewPager.setCurrentItem(1);
                setUnpress();
                setPress(icon_wbapp, text_wbapp, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_saved).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                startActivity(new Intent(MainActivity.this, MyStatusActivity.class));
                setUnpress();
                setPress(icon_saved, text_saved, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_web).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                startActivity(new Intent(MainActivity.this, WAWebActivity.class));
                setUnpress();
                setPress(icon_web, text_web, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_chat).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                startActivity(new Intent(MainActivity.this, DChatActivity.class));
                setUnpress();
                setPress(icon_chat, text_chat, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_how).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                startActivity(new Intent(MainActivity.this, HelpActivity.class));
                setUnpress();
                setPress(icon_how, text_how, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_share).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                drawerLayout.closeDrawers();
                shareApp();
                setUnpress();
                setPress(icon_share, text_share, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_rate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                drawerLayout.closeDrawers();
                rateUs();
                setUnpress();
                setPress(icon_rate, text_rate, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_more).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                drawerLayout.closeDrawers();
                moreApp();
                setUnpress();
                setPress(icon_more, text_more, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_font).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                startActivity(new Intent(MainActivity.this, FontActivity.class));
                setUnpress();
                setPress(icon_font, text_font, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_wrecover).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                startActivity(new Intent(MainActivity.this, DeletedMsgActivity.class));
                setUnpress();
                setPress(icon_wrecover, text_wrecover, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_privacy).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                startActivity(new Intent(MainActivity.this, PolicyActivity.class));

                setUnpress();
                setPress(icon_privacy, text_privacy, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.drw_lang).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                drawerLayout.closeDrawers();
                dialogLang.show();
                setUnpress();
                setPress(icon_lang, text_lang, R.color.drawer_press);
            }
        });

        navigationView.findViewById(R.id.exit_app).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                drawerLayout.closeDrawers();
                exitDialog();
                setUnpress();
                setPress(icon_exit, text_exit, R.color.drawer_press);
            }
        });
        findViewById(R.id.menu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(Gravity.LEFT);
            }
        });


        initDrawer();

        wAppAlert();
        to_whatsap = findViewById(R.id.to_whatsap);
        to_whatsap.setOnClickListener(v -> {
            dialog.show();
        });

        langAlert();

        container = findViewById(R.id.banner_container);
        if (AdController.isLoadIronSourceAd) {
            AdController.inItIron(MainActivity.this);
        } else {
            /*admob*/
            AdController.loadBannerAd(MainActivity.this, container);
            AdController.loadInterAd(MainActivity.this);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (AdController.isLoadIronSourceAd) {
            AdController.destroyIron();
            AdController.ironBanner(MainActivity.this, container);
            // call the IronSource onResume method
            IronSource.onResume(this);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (AdController.isLoadIronSourceAd) {
            // call the IronSource onPause method
            IronSource.onPause(this);
        }
    }

    boolean isOpedrw_wapp = false, isOpedrw_wbapp = false;

    void wAppAlert() {
        dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.popup_lay);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        RelativeLayout btdrw_wapp = dialog.findViewById(R.id.btn_wapp);
        RelativeLayout btdrw_wappBus = dialog.findViewById(R.id.btn_wapp_bus);

        btdrw_wapp.setOnClickListener(arg0 -> {
            try {
                isOpedrw_wapp = true;
                startActivity(getPackageManager().getLaunchIntentForPackage("com.whatsapp"));
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Please Install WhatsApp For Download Status!!!!!", Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();

        });

        btdrw_wappBus.setOnClickListener(arg0 -> {
            try {
                isOpedrw_wbapp = true;
                startActivity(getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b"));
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Please Install WhatsApp Business For Download Status!!!!!", Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        });

    }


    void langAlert() {
        dialogLang = new Dialog(MainActivity.this);
        dialogLang.setContentView(R.layout.lang_lay);

        dialogLang.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView txtEn = dialogLang.findViewById(R.id.txt_en);
        TextView txtHi = dialogLang.findViewById(R.id.txt_hi);
        TextView txtAr = dialogLang.findViewById(R.id.txt_ar);

        txtEn.setOnClickListener(arg0 -> {
            SharedPrefs.setLang(MainActivity.this, "en");
            dialogLang.dismiss();
            refresh();
        });

        txtHi.setOnClickListener(arg0 -> {
            SharedPrefs.setLang(MainActivity.this, "hi");
            dialogLang.dismiss();
            refresh();
        });

        txtAr.setOnClickListener(arg0 -> {
            SharedPrefs.setLang(MainActivity.this, "ar");
            dialogLang.dismiss();
            refresh();
        });

    }

    void refresh() {
        finish();
        startActivity(getIntent());
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    ViewPagerAdapter adapter;

    private void setupViewPager(ViewPager viewPager) {
        adapter = new ViewPagerAdapter(getSupportFragmentManager());

        adapter.addFragment(new RecentWapp(), "Whatsapp");
        adapter.addFragment(new RecentWappBus(), "WA Business");

        viewPager.setAdapter(adapter);
    }

    static class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int arg0) {
            return this.mFragmentList.get(arg0);
        }

        @Override
        public int getCount() {
            return this.mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return this.mFragmentTitleList.get(position);
        }
    }

    private void setupTabIcons() {
        View v = LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        TextView txt = v.findViewById(R.id.tab);
        txt.setText(tabs[0]);
        txt.setTextColor(getResources().getColor(R.color.tab_txt_press));
        txt.setBackgroundResource(R.drawable.press);
        FrameLayout.LayoutParams tabp = new FrameLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels * 438 / 1080, getResources().getDisplayMetrics().heightPixels * 140 / 1920);
        txt.setLayoutParams(tabp);
        TabLayout.Tab tab = tabLayout.getTabAt(0);
        tab.setCustomView(null);
        tab.setCustomView(v);
    }

    public View getTabView(int pos) {
        View v = LayoutInflater.from(MainActivity.this).inflate(R.layout.custom_tab, null);
        TextView txt = v.findViewById(R.id.tab);
        txt.setText(tabs[pos]);
        txt.setTextColor(getResources().getColor(R.color.tab_txt_press));
        txt.setBackgroundResource(R.drawable.press);
        FrameLayout.LayoutParams tab = new FrameLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels * 438 / 1080, getResources().getDisplayMetrics().heightPixels * 140 / 1920);
        txt.setLayoutParams(tab);
        return v;
    }

    public View getTabViewUn(int pos) {
        View v = LayoutInflater.from(MainActivity.this).inflate(R.layout.custom_tab, null);
        TextView txt = v.findViewById(R.id.tab);
        txt.setText(tabs[pos]);
        txt.setTextColor(getResources().getColor(R.color.tab_txt_unpress));
        txt.setBackgroundResource(R.drawable.unpress);
        FrameLayout.LayoutParams tab = new FrameLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels * 438 / 1080, getResources().getDisplayMetrics().heightPixels * 140 / 1920);
        txt.setLayoutParams(tab);
        return v;
    }

    public void initDrawer() {
        drw_wapp = findViewById(R.id.drw_wapp);
        drw_wbapp = findViewById(R.id.drw_wbapp);
        drw_saved = findViewById(R.id.drw_saved);
        drw_lang = findViewById(R.id.drw_lang);
        drw_share = findViewById(R.id.drw_share);
        drw_rate = findViewById(R.id.drw_rate);
        drw_privacy = findViewById(R.id.drw_privacy);
        drw_more = findViewById(R.id.drw_more);
        drw_how = findViewById(R.id.drw_how);
        drw_web = findViewById(R.id.drw_web);
        drw_chat = findViewById(R.id.drw_chat);
        drw_font = findViewById(R.id.drw_font);
        drw_wrecover = findViewById(R.id.drw_wrecover);

        icon_wapp = findViewById(R.id.icon_wapp);
        icon_wbapp = findViewById(R.id.icon_wbapp);
        icon_saved = findViewById(R.id.icon_saved);
        icon_dark = findViewById(R.id.icon_dark);
        icon_exit = findViewById(R.id.icon_exit);
        icon_lang = findViewById(R.id.icon_lang);
        icon_share = findViewById(R.id.icon_share);
        icon_rate = findViewById(R.id.icon_rate);
        icon_privacy = findViewById(R.id.icon_privacy);
        icon_more = findViewById(R.id.icon_more);
        icon_how = findViewById(R.id.icon_how);
        icon_web = findViewById(R.id.icon_web);
        icon_chat = findViewById(R.id.icon_chat);
        icon_font = findViewById(R.id.icon_font);
        icon_wrecover = findViewById(R.id.icon_wrecover);

        text_wapp = findViewById(R.id.text_wapp);
        text_wbapp = findViewById(R.id.text_wbapp);
        text_saved = findViewById(R.id.text_saved);
        text_exit = findViewById(R.id.text_exit);
        text_dark = findViewById(R.id.text_dark);
        text_lang = findViewById(R.id.text_lang);
        text_share = findViewById(R.id.text_share);
        text_rate = findViewById(R.id.text_rate);
        text_privacy = findViewById(R.id.text_privacy);
        text_more = findViewById(R.id.text_more);
        text_how = findViewById(R.id.text_how);
        text_web = findViewById(R.id.text_web);
        text_chat = findViewById(R.id.text_chat);
        text_font = findViewById(R.id.text_font);
        text_wrecover = findViewById(R.id.text_wrecover);

        modeSwitch = findViewById(R.id.modeSwitch);
        int mode = SharedPrefs.getAppNightDayMode(this);
        if (mode == AppCompatDelegate.MODE_NIGHT_YES) {
            modeSwitch.setChecked(true);
        } else {
            modeSwitch.setChecked(false);
        }
        modeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                SharedPrefs.setInt(this, SharedPrefs.PREF_NIGHT_MODE, AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                SharedPrefs.setInt(this, SharedPrefs.PREF_NIGHT_MODE, AppCompatDelegate.MODE_NIGHT_NO);
            }
        });
    }

    void setUnpress() {
        setPress(icon_wapp, text_wapp, R.color.drawer_unpress);
        setPress(icon_wbapp, text_wbapp, R.color.drawer_unpress);
        setPress(icon_saved, text_saved, R.color.drawer_unpress);
        setPress(icon_exit, text_exit, R.color.drawer_unpress);
        setPress(icon_lang, text_lang, R.color.drawer_unpress);
        setPress(icon_how, text_how, R.color.drawer_unpress);
        setPress(icon_share, text_share, R.color.drawer_unpress);
        setPress(icon_rate, text_rate, R.color.drawer_unpress);
        setPress(icon_privacy, text_privacy, R.color.drawer_unpress);
        setPress(icon_more, text_more, R.color.drawer_unpress);
        setPress(icon_web, text_web, R.color.drawer_unpress);
        setPress(icon_chat, text_chat, R.color.drawer_unpress);
        setPress(icon_font, text_font, R.color.drawer_unpress);
        setPress(icon_wrecover, text_wrecover, R.color.drawer_unpress);
    }

    Intent setPress(ImageView imageView, TextView textView, int color) {
        imageView.setColorFilter(ContextCompat.getColor(MainActivity.this, color), PorterDuff.Mode.SRC_IN);
        textView.setTextColor(getResources().getColor(color));
        return null;
    }

    void navigate(Intent intent) {
        if (AdController.isLoadIronSourceAd) {
            AdController.ironShowInterstitial(MainActivity.this, intent, 0);
        } else {
            AdController.showInterAd(MainActivity.this, intent, 0);
        }
    }

    public void shareApp() {
        Intent myapp = new Intent(Intent.ACTION_SEND);
        myapp.setType("text/plain");
        myapp.putExtra(Intent.EXTRA_TEXT, "Download this awesome app\n https://play.google.com/store/apps/details?id=" + getPackageName() + " \n");
        startActivity(myapp);
    }

    public void rateUs() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    public void moreApp() {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/dev?id=7081479513420377164&hl=en")));
    }

    private long mLastBackClick = 0;

    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() - mLastBackClick < 1100) {
            super.onBackPressed();
        } else {
            AdController.adCounter++;
            if (AdController.adCounter == AdController.adDisplayCounter) {
                AdController.showInterAd(MainActivity.this, null, 0);
            } else {
                Toast.makeText(MainActivity.this, getResources().getString(R.string.exit_alert), Toast.LENGTH_SHORT).show();
                mLastBackClick = System.currentTimeMillis();
            }
        }
    }

    private void exitDialog() {

        new CustomDialog(this)
                .setIcon(R.drawable.ic_exit)
                .setTitle("Exit App", true)
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Exit", new CustomDialog.OnClickListener() {
                    @Override
                    public void onClick(CustomDialog customDialog) {
                        finishAffinity();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

}