package slidingrootnav.callback;

public interface DragListener {

    void onDrag(float progress);
}
